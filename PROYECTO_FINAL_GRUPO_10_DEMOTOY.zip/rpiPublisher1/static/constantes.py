# Url views statics
TEMPLATE_INDEX_CONSTANTE = '/index.html'
TEMPLATE_REGISTRO_CONSTANTE = '/registro.html'
TEMPLATE_PRINCIPAL_CONSTANTE = '/principal.html'

# Url directions
DIRECCION_PRINCIPAL_CONSTANTE = '/principal'
DIRECCION_INDEX_CONSTANTE = '/'

# Rpi statics
SECUANCIA_SEGUNDOS_RPI = 10

# Rpi pins
VENTILADOR_PIN = 10